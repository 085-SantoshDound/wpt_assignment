const url = '';
let datab = {
  host: 'localhost',
  user: 'root',
  password: '1234',
  database: 'gym_database',
  port: 3306,
};
const mysql = require('mysql2');
const con = mysql.createConnection(datab);

console.log('Database adventures');
